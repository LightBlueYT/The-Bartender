## General

* Updated command: bot
* New command: help
* Updated command: clean
* New command: clean
* Updated event: guildMemberAdd
* Updated event: guildCreate
* Updated event: ready
* New command: bot
* New event: ready
* New event: guildMemberAdd
* New event: guildCreate
* Bot created

***

## News

* Added **help** command, shows all commands + command information 2019-12-31: 13.10
* **clean** command added, fully purges a channel from messages 2019-12-31: 11.34
* **bot** command added, shows bot info 2019-12-31: 10.55
* ready event made 2019-12-31: 09.04
* guildMemberAdd event made 2019-12-31: 08.25
* guildCreate event made 2019-12-30: 21.43
* Bot made 2019-12-30: 20.10

***

## Updates

* Updated bot command, now shows dev build version in footer 2019-12-31: 13.21
* Updated clean command, checks for manage_server permission 2019-12-31: 12.45
* Updated guildMemberAdd event 2019-12-31: 11.18
* Updated guildCreate event 2019-12-31: 11.12
* Updated ready event 2019-12-31: 11:04
